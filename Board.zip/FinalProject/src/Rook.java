
public class Rook extends Piece
{

}
