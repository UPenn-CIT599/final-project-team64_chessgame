
public class Knight extends Piece
{

}
