
public class Queen extends Piece
{

}
