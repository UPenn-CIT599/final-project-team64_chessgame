
public class Piece
{
	

}
