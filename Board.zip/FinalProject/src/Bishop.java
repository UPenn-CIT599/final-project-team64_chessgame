
public class Bishop extends Piece
{

}
