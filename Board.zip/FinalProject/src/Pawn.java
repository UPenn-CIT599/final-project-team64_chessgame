
public class Pawn extends Piece
{

}
