
public class King extends Piece
{
	
}
